<?php


namespace Tarikh\PhpMeta\Lib;


class EnTradeActions
{
    const TA_DEALER_POS_EXECUTE = 200;
}
