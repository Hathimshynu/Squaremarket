<?php

namespace Tarikh\PhpMeta\Exceptions;

use Exception;

class TradeException extends Exception
{
    //
}
