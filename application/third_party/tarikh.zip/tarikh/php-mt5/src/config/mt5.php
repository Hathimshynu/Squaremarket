<?php

return [
    'server'    => env('MT5_SERVER_IP', '127.0.0.1'),
    'port'      => env('MT5_SERVER_PORT', 443),
    'login'     => env('MT5_SERVER_WEB_LOGIN', 1),
    'password'  => env('MT5_SERVER_WEB_PASSWORD', null)
];
