<?php

namespace Tarikh\PhpMeta\Exceptions;

use Exception;

class UserException extends Exception
{
    //
}
