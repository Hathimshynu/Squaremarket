<?php

namespace Tarikh\PhpMeta\Exceptions;

use Exception;

class ConnectionException extends Exception
{
    //
}
